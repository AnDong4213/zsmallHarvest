Component({
  properties: {
    title: {
      type: String,
      value: ''
    },
    content: {
      type: String,
      value: ''
    },
    isCon: {
      type: Boolean,
      value: false
    },
    arrData: {
      type: Array,
      value: []
    },
    objData: {
      type: Object,
      value: {}
    }
  },
  data: {

  },
  methods: {
    close() {
      this.triggerEvent('customclose')
    }
  },
  options: {
    multipleSlots: true
  }
})