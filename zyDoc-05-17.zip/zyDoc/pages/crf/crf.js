const app = getApp(), baseUrl = app.globalData.baseUrl;

Page({
  data: {
    currentTab: '2',
    item: {
      drugName: '枳术宽中胶囊药物'
    },
    content: "",
    isMask: false,
    isAdd: false,
    isCon: false,
    title: '',
    subject: [{ visitNum: 1, con: '访视1' }, { visitNum: 2, con: '访视2' },
      { visitNum: 3, con: '访视3' }, { visitNum: 4, con: '访视4' },
      { visitNum: 5, con: '访视5' }, { visitNum: 6, con: '访视6' }],
    patientItem: {},
    proItem: {},
    isBo: false,
    grouping: [],
    filObj: {}
  },

  onLoad: function () {
    let patientItem = wx.getStorageSync('patientItem'), proItem = wx.getStorageSync('proItem'), crfItem = wx.getStorageSync('crfItem');
    /* console.log(patientItem)
    console.log(proItem) */
    this.setData({
      patientItem,
      proItem
    });
    if (!crfItem.crfId) {
      wx.request({
        method: 'POST',
        url: `${baseUrl}/crf/save`,
        data: {
          projectId: proItem.projectId,
          doctorId: proItem.doctorId,
          patientId: patientItem.patientId
        },
        header: {
          'content-type': 'application/json'
        },
        success({data: {data, statusCode}}) {
          if (statusCode == "2000000") {
            wx.setStorageSync('crfItem', data)
          }
        }
      })
    }
  },
  navbarTap(e) {
    let currentTab = e.currentTarget.dataset.index;
    this.setData({
      currentTab
    })
  },
  checkboxChange(e) {
    console.log(e.detail.value)
  },
  hehe(e) {
    console.log(e)
  },
  closeMask() {
    this.setData({
      isMask: false,
      isAdd: false,
      content: '',
      isCon: false,
      title: ''
    })
  },
  login() {
    this.setData({
      isMask: false,
      isAdd: false,
      content: '',
      isCon: false,
      title: ''
    })
  },
  visitOne() {
    this.setData({
      title: '选择访视',
      isMask: true,
      isAdd: true
    })
  },
  grouping() {
    let that = this;
    wx.request({
      method: 'POST',
      url: `${baseUrl}/projectGroup/getList`,
      data: {
        projectId: wx.getStorageSync('crfItem').projectId
      },
      header: {
        'content-type': 'application/json'
      },
      success({ data: { data, statusCode } }) {
        // console.log(data)
        if (statusCode == "2000000") {
          that.setData({
            isBo: true,
            grouping: data
          })
        } else {
          wx.showToast({
            title: '分组数据获取失败',
            icon: 'none',
            duration: 1000
          })
        }
      }
    })
  },
  groupingRadio(e) {
    let grouping = this.data.grouping;
    let fil = grouping.filter(item => item.id == e.detail.value)
    let filObj = fil[0];
    filObj.medicineInfoName = JSON.parse(fil[0].medicineInfo)[0].medicineId
    // console.log(filObj)
    this.setData({
      isBo: false,
      filObj
    })
  }
})