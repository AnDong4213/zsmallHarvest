const app = getApp(), baseUrl = app.globalData.baseUrl;

Page({
  data: {
    sex: 1,
    patientName: '',
    birthday: '',
    height: '',
    idCard: '',
    phone: '',
    weight: ''
  },
  onLoad: function (options) {
    let doctorItem = wx.getStorageSync('doctorItem');
    console.log(doctorItem)
  },
  name(e) {
    this.setData({
      patientName: e.detail.value
    })
  },
  radioDrink(e) {
    if (e.detail.value == 'nan') {
      this.setData({
        sex: 1
      })
      return;
    };
    this.setData({
      sex: 2
    })
  },
  bindDateChange(e) {
    this.setData({
      birthday: e.detail.value
    })
  },
  height(e) {
    this.setData({
      height: e.detail.value
    })
  },
  weight(e) {
    this.setData({
      weight: e.detail.value
    })
  },
  nation(e) {

  },
  idCard(e) {
    this.setData({
      idCard: e.detail.value
    })
  },
  phone(e) {
    this.setData({
      phone: e.detail.value
    })
  },
  address(e) {

  },
  create() {
    let para = {
      sex: this.data.sex,
      patientName: this.data.patientName,
      birthday: this.data.birthday,
      height: this.data.height,
      idCard: this.data.idCard,
      phone: this.data.phone,
      weight: this.data.weight,
      doctorId: wx.getStorageSync('doctorItem').doctorId
    }, that = this;
    wx.request({
      method: 'POST',
      url: `${baseUrl}/projectPatient/save`,
      data: {
        ...para
      },
      header: {
        'content-type': 'application/json'
      },
      success({data: {data, statusCode}}) {
        if (statusCode == "2000000") {
          wx.showToast({
            title: '添加成功',
            icon: 'success',
            duration: 1000
          })
          that.setData({
            patientName: '',
            birthday: '',
            height: '',
            idCard: '',
            phone: '',
            weight: ''
          })
        } else {
          wx.showToast({
            title: '添加失败',
            icon: 'none',
            duration: 1000
          })
        }
      }
    })
    // console.log(para)
  }

})