Page({
  data: {
    degreeZ: ['轻', '中', '重'],
    degree: '',
    degreeindex: 0,
    traitZ: ['阵发性', '持续性', '其他'],
    trait: '',
    traitindex: 1,
    eventName: '',
    diagnosis: '',
    numberN: '',
    process: '',
    inspect: '',
    inspectIs: false,
    measuresZ: ['剂量不变', '减少剂量', '暂停用药', '停止用药', '试验用药已结束', '其他'],
    measures: '',
    measuresindex: 0,
    handleProcessIs: false,
    relationindex: 0,
    relationZ: ['肯定有关', '很可能有关', '可能有关', '可能无关', '肯定无关'],
    relation: '',
    visitTime: '',
    visit_time: '',
    occurTime: '',
    occur_time: '',
    visitInspectIs: false,
    visitInspect: '',
    transferZ: ['消失/复常', '好装', '未好转', '未知', '有后遗症'],
    transfer: '',
    transferindex: 0,
    isOut: 0
  },
  onLoad: function (options) {

  },
  eventName(e) {
    this.setData({
      eventName: e.detail.value
    })
  },
  diagnosis(e) {
    this.setData({
      diagnosis: e.detail.value
    })
  },
  occurTime(e) {
    let dateH = new Date(), hour = dateH.getHours(), minute = dateH.getMinutes(), second = dateH.getSeconds();
    let sfm = hour + ':' + minute;
    this.setData({
      occurTime: e.detail.value + ' ' + sfm,
      occur_time: e.detail.value + ' ' +sfm+':00'
    })
  },
  degree(e) {
    this.setData({
      degreeindex: e.detail.value,
      degree: this.data.degreeZ[e.detail.value]
    })
  },
  trait(e) {
    this.setData({
      traitindex: e.detail.value,
      trait: this.data.traitZ[e.detail.value]
    })
  },
  numberN(e) {

  },
  process(e) {
    this.setData({
      process: e.detail.value
    })
  },
  inspect(e) {
    if (e.detail.value == 'yes') {
      this.setData({
        inspectIs: true,
        inspect: '1'
      })
    } else {
      this.setData({
        inspectIs: false,
        inspect: '0'
      })
    }
  },
  inspectInput(e) {

  },
  measures(e) {
    this.setData({
      measuresindex: e.detail.value,
      measures: this.data.measuresZ[e.detail.value]
    })
  },
  measuresInput(e) {

  },
  handleProcess(e) {
    if (e.detail.value == 'yes') {
      this.setData({
        handleProcessIs: true,
        handleProcess: '1'
      })
    } else {
      this.setData({
        handleProcessIs: false,
        handleProcess: '0'
      })
    }
  },
  handleProcessInput(e) {

  },
  relation(e) {
    this.setData({
      relationindex: e.detail.value,
      relation: this.data.relationZ[e.detail.value]
    })
  },
  visitTime(e) {
    let dateH = new Date(), hour = dateH.getHours(), minute = dateH.getMinutes(), second = dateH.getSeconds();
    let sfm = hour + ':' + minute;
    this.setData({
      visitTime: e.detail.value + ' ' + sfm,
      visit_time: e.detail.value + ' ' +sfm+':00'
    })
  },
  visitInspect(e) {
    if (e.detail.value == 'yes') {
      this.setData({
        visitInspectIs: true,
        visitInspect: '1'
      })
    } else {
      this.setData({
        visitInspectIs: false,
        visitInspect: '0'
      })
    }
  },
  visitInspectInput(e) {

  },
  transfer(e) {
    this.setData({
      transferindex: e.detail.value,
      transfer: this.data.transferZ[e.detail.value]
    })
  },
  transferInput(e) {

  },
  isOut(e) {
    if (e.detail.value == 'yes') {
      this.setData({
        isOut: 1
      })
    } else {
      this.setData({
        isOut: 0
      })
    }
  },

  create() {
    let {
      degree,
      diagnosis,
      eventName,
      handleProcess,
      inspect,
      isOut,
      measures,
      occur_time,
      process,
      relation,
      trait,
      transfer,
      visitInspect,
      visit_time
    } = this.data;
    let para = {
      degree,
      diagnosis,
      eventName,
      handleProcess,
      inspect,
      isOut,
      measures,
      occur_time,
      process,
      relation,
      trait,
      transfer,
      visitInspect,
      visit_time
    };
    console.log(para)
  }

}) 