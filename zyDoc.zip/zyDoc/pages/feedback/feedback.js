Page({
  data: {
    list: {},
    morNum: 0,
    midNum: 2,
    nightNum: 3,
    arr: [],
    sysW: null,
    weekArr: ['日', '一', '二', '三', '四', '五', '六'],
    ny: null,
    marLet: null,
    getDate: null,
    red: '#f00',
    blue: '#0ABA07',
    relative: 'relative'
  },

  dataTime() {
    let date = new Date(), year = date.getFullYear(), months = date.getMonth() + 1;
    //最后一天是几号 
    let d = new Date(year, months, 0);
    //第一天星期几 
    let firstDay = new Date(year, months - 1, 1);
    //根据得到今月的最后一天日期遍历 得到所有日期
    let arr = [];
    for (var i = 1; i < d.getDate() + 1; i++) {
      arr.push(i);
    }
    this.setData({
      ny: year + '-' + (months > 10 ? months : '0' + months),
      getDate: date.getDate(),
      //更具屏幕宽度变化自动设置宽度 
      marLet: firstDay.getDay(),
      arr
    })
  },
  clickDate(e) {
    console.log(e.currentTarget.dataset)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // let list = JSON.parse(options.list);
    // console.log(list)
    this.dataTime();
    let res = wx.getSystemInfoSync();
    this.setData({
      sysW: res.windowHeight / 12
    })
  },
  bindDateChange: function (e) {
    let time = e.detail.value.split('-'), months = parseInt(time[1]), date = new Date();
    let d = new Date(time[0], months, 0), firstDay = new Date(time[0], months - 1, 1), arr = [];
    for (var i = 1; i < d.getDate() + 1; i++) {
      arr.push(i);
    }
    this.setData({
      ny: time[0] + '-' + time[1],
      getDate: date.getDate(),
      marLet: firstDay.getDay(),
      arr
    })
  },
  radiochange(e) {
    console.log(e.detail)
  },
  morMinus() {
    let morNum = this.data.morNum;
    morNum--;
    if (morNum < 0) {
      morNum = 0;
    }
    this.setData({
      morNum
    })
  },
  morAdd() {
    let morNum = this.data.morNum;
    morNum++;
    this.setData({
      morNum
    })
  },
  midMinus() {
    let midNum = this.data.midNum;
    midNum--;
    if (midNum < 0) {
      midNum = 0;
    }
    this.setData({
      midNum
    })
  },
  midAdd() {
    let midNum = this.data.midNum;
    midNum++;
    this.setData({
      midNum
    })
  },
  nightMinus() {
    let nightNum = this.data.nightNum;
    nightNum--;
    if (nightNum < 0) {
      nightNum = 0;
    }
    this.setData({
      nightNum
    })
  },
  nightAdd() {
    let nightNum = this.data.nightNum;
    nightNum++;
    this.setData({
      nightNum
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})