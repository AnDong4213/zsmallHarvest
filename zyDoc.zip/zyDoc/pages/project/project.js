const app = getApp(), baseUrl = app.globalData.baseUrl;

Page({
  data: {
    currentTab: '0',
    isexpand: true,
    title: '',
    content: "",
    isMask: false,
    isAdd: false,
    isCon: false,
    proItem: {},
    standardr: [],
    standardp: [],
    progroup: [],
    arrData: [],
    list: [
      {
        name: '张明星',
        job: '副主任医生',
        hospital: '北京协和医院',
        department: '骨科'
      },
      {
        name: '张明星',
        job: '副主任医生',
        hospital: '北京协和医院',
        department: '骨科'
      }
    ],
    subject: [],
    choosen: [],
    subtest: []
  },
  onLoad: function () {
    let proItem = wx.getStorageSync('proItem');
    console.log(proItem)
    proItem.projectEndDate = proItem.projectEndDate.split(' ')[0];
    proItem.projectStartDate = proItem.projectStartDate.split(' ')[0];
    this.setData({
      proItem,
      testDesign: proItem.testDesign,
      testPurpose: proItem.testPurpose,
      curePlan: proItem.curePlan,
      cureStandard: proItem.cureStandard,
      cureJudgeStandard: proItem.cureJudgeStandard,
      cureSecurityStandard: proItem.cureSecurityStandard,
    })
  },
  navbarTap(e) {
    let currentTab = e.currentTarget.dataset.index, that = this;
    if (currentTab == '1') {
      wx.request({
        method: 'POST',
        url: `${baseUrl}/projectPatient/getList`,
        data: {
          projectId: that.data.proItem.projectId,
          doctorId: wx.getStorageSync('doctorItem').doctorId
        },
        header: {
          'content-type': 'application/json'
        },
        success({data: {data, statusCode}}) {
          if (statusCode == "2000000") {
            data.forEach(item => {
              item.sex = item.sex == 1 ? '男' : '女'; 
            })
            that.setData({
              subtest: data
            })
          }
        }
      })
    }
    this.setData({
      currentTab
    })
  },
  doctor() {
    wx.navigateTo({
      url: './../reteam/reteam'
    })
  },
  givedrug() {
    wx.navigateTo({
      url: './../drugcf/drugcf'
    })
  },
  crfreport(e) {
    wx.setStorageSync('patientItem', e.currentTarget.dataset.list)
    wx.navigateTo({
      url: './../crf/crf'
    })
  },
  isexpand() {
    let that = this;
    wx.request({
      method: 'POST',
      url: `${baseUrl}/projectChoose/getList`,
      data: {
        projectId: that.data.proItem.projectId
      },
      header: {
        'content-type': 'application/json'
      },
      success({data: {data, statusCode}}) {
        if (statusCode == "2000000") {
          // console.log(data)
          let standardr = data.filter(item => item.chooseType == 1);
          let standardp = data.filter(item => item.chooseType == 2);
          that.setData({
            standardr,
            standardp
          })
        }
      }
    })
    wx.request({
      method: 'POST',
      url: `${baseUrl}/projectGroup/getList`,
      data: {
        projectId: that.data.proItem.projectId
      },
      header: {
        'content-type': 'application/json'
      },
      success({data: {data, statusCode}}) {
        if (statusCode == "2000000") {
          that.setData({
            progroup: data
          })
        }
      }
    })
    this.setData({
      isexpand: false
    })
  },
  progroup(e) {
    this.setData({
      title: '药品名称',
      isMask: true,
      arrData: JSON.parse(e.currentTarget.dataset.info)
    })
  },
  isCollapse() {
    this.setData({
      isexpand: true
    })
  },
  addTo() {
    let that = this;
    wx.request({
      method: 'POST',
      url: `${baseUrl}/projectPatient/getList`,
      data: {
        doctorId: wx.getStorageSync('doctorItem').doctorId
      },
      header: {
        'content-type': 'application/json'
      },
      success({data: {data, statusCode}}) {
        console.log(data)
        if (statusCode == "2000000") {
          data.forEach(item => {
            item.sex = item.sex == 1 ? '男' : '女'; 
          })
          that.setData({
            subject: data
          })
        }
      }
    })
    this.setData({
      title: '添加受试者',
      isMask: true,
      isAdd: true
    })
  },
  besure() {
    let that = this;
    wx.request({
      method: 'POST',
      url: `${baseUrl}/projectPatient/update`,
      data: {
        projectPatientDTOList: that.data.choosen
      },
      header: {
        'content-type': 'application/json'
      },
      success({data: {data, statusCode}}) {
        if (statusCode == "2000000") {
          wx.showToast({
            title: '添加成功',
            icon: 'success',
            duration: 1000
          })
          that.closeMask();
        } else {
          wx.showToast({
            title: '添加失败',
            icon: 'none',
            duration: 1000
          })
        }
      }
    })
  },
  syDesign() {
    this.setData({
      title: '试验设计',
      content: this.data.testDesign,
      isMask: true,
      isCon: true
    })
  },
  syPurpose() {
    this.setData({
      title: '试验目的',
      content: this.data.testPurpose,
      isMask: true,
      isCon: true
    })
  },
  zlprograms() {
    this.setData({
      title: '治疗方案',
      content: this.data.curePlan,
      isMask: true,
      isCon: true
    })
  },
  zlzhibiao() {
    this.setData({
      title: '治疗指标',
      content: this.data.cureStandard,
      isMask: true,
      isCon: true
    })
  },
  zlbiaozhun() {
    this.setData({
      title: '疗效判定标准',
      content: this.data.cureJudgeStandard,
      isMask: true,
      isCon: true
    })
  },
  safezb() {
    this.setData({
      title: '安全性指标',
      content: this.data.cureSecurityStandard,
      isMask: true,
      isCon: true
    })
  },
  closeMask() {
    this.setData({
      isMask: false,
      isAdd: false,
      content: '',
      isCon: false,
      arrData: []
    })
  },
  checkboxChange(e) {
    let choosen = [], proItem = wx.getStorageSync('proItem'), arr = e.detail.value;
    arr.forEach(item => {
      let obj = {};
      obj.id = item;
      obj.projectId = proItem.projectId;
      obj.projectName = proItem.projectName;
      choosen.push(obj)
    })
    this.setData({
      choosen
    })
  }
})