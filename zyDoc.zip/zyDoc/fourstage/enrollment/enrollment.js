const app = getApp(), baseUrl = app.globalData.baseUrl;

Component({
  properties: {
    innerText: {
      type: String,
      value: '入组期'
    },
    filObj: {
      type: Object,
      value: {}
    }
  },
  data: {
    clinical: [],
    num: 0,
    dateOne: '',
    dateTwo: '',
    dateThree: '',
    dateFour: '',
    dateFive: '',
    initialzz: '',
    initialpg: '',
    ifjoin: false,
    standardr: [],
    standardp: [],
    isGroup: '0',
    enterData: {},
    crfList: []
  },
  lifetimes: {
    attached () {
      let crfItem = wx.getStorageSync('crfItem'), that = this;
      console.log(crfItem);
      /* wx.request({
        method: 'POST',
        url: `${baseUrl}/projectChoose/getList`,
        data: {
          projectId: wx.getStorageSync('crfItem').projectId
        },
        header: {
          'content-type': 'application/json'
        },
        success({data: {data, statusCode}}) {
          if (statusCode == "2000000") {
            let standardr = data.filter(item => item.chooseType == 1);
            let standardp = data.filter(item => item.chooseType == 2);
            that.setData({
              standardr,
              standardp
            })
          }
        }
      }) */

      function initial() {
        return new Promise((resolve, reject) => {
          wx.request({
            method: 'POST',
            url: `${baseUrl}/crfInto/getList`,
            data: {
              crfId: wx.getStorageSync('crfItem').crfId
            },
            header: {
              'content-type': 'application/json'
            },
            success({data: {data, statusCode}}) {
              if (statusCode == "2000000") {
                if (data[0] && data[0].intoId) {
                  console.log(data[0])
                  data[0].firstTime = data[0].firstTime.split(' ')[0];
                  data[0].intoDate = data[0].intoDate.split(' ')[0];
                  data[0].nextTime = data[0].nextTime.split(' ')[0];
                  data[0].useMedicineTime = data[0].useMedicineTime.split(' ')[0];
                  that.setData({
                    enterData: data[0],
                    ifjoin: true
                  });
                  resolve(data[0].intoId)
                }
              }
            }
          })
        })
      };
      initial().then(res => {
        console.log(res);
        wx.request({
          method: 'POST',
          url: `${baseUrl}/crfClinical/getList`,
          data: {
            relationId: res
          },
          header: {
            'content-type': 'application/json'
          },
          success({data: {data, statusCode}}) {
            if (statusCode == "2000000") {
              console.log(data);
              that.setData({
                crfList: data
              })
            }
          }
        })
      })

    }
  },
  methods: {
    bindDateChangeOne(e) {
      this.setData({
        dateOne: e.detail.value
      })
    },
    bindDateChangeTwo(e) {
      this.setData({
        dateTwo: e.detail.value
      })
    },
    bindDateChangeThree(e) {
      this.setData({
        dateThree: e.detail.value
      })
    },
    bindDateChangeFour(e) {
      this.setData({
        dateFour: e.detail.value
      })
    },
    bindDateChangeFive(e) {
      this.setData({
        dateFive: e.detail.value
      })
    },
    initialzz(e) {
      this.setData({
        initialzz: e.detail.value
      })
    },
    initialpg(e) {
      this.setData({
        initialpg: e.detail.value
      })
    },
    initialzzAll(e) {
      let idx = e.currentTarget.dataset.idx, clinical = this.data.clinical;
      clinical[idx].symptom = e.detail.value;
      this.setData({
        clinical
      })
    },
    initialpgAll(e) {
      let idx = e.currentTarget.dataset.idx, clinical = this.data.clinical;
      clinical[idx].score = e.detail.value;
      this.setData({
        clinical
      })
    },
    midAdd() {
      let clinical = this.data.clinical, obj = {};
      let initialzz = this.data.initialzz, initialpg = this.data.initialpg;
      if (initialzz != '' && initialpg != '') {
        if (clinical.length > 0) {
          let idx = clinical.length - 1;
          if (clinical[idx].symptom != '' && clinical[idx].score != '') {
            obj.symptom = '';
            obj.score = '';
            // obj.rand = Math.random().toFixed(8);
            clinical.push(obj);
            this.setData({
              clinical
            });
            return
          } else {
            wx.showToast({
              title: '请输入症状和评估值',
              icon: 'none',
              duration: 1000
            })
          }
          return
        }
        obj.symptom = '';
        obj.score = '';
        // obj.rand = Math.random().toFixed(8);
        clinical.push(obj);
        this.setData({
          clinical
        })
      } else {
        wx.showToast({
          title: '请输入症状和评估值',
          icon: 'none',
          duration: 1000
        })
      }
    },
    midMinus(e) {
      let clinical = this.data.clinical, idx = e.currentTarget.dataset.idx;
      clinical.splice(idx, 1);
      console.log(clinical)
      this.setData({
        clinical
      })
    },
    ifjoin(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          ifjoin: true,
          isGroup: '1'
        })
      } else {
        this.setData({
          ifjoin: false,
          isGroup: '0'
        })
      }
    },
    selected(e) {
      console.log(e.detail.value)
    },
    grouping() {
      if (!this.data.enterData.intoId) {
        this.triggerEvent('grouping');
      }
    },
    login() {
      if (this.data.initialzz != '') {
        let clinical = this.data.clinical;
        clinical.unshift({symptom: this.data.initialzz, score: this.data.initialpg});
        clinical.forEach(item => {
          item.relationId = this.data.enterData.intoId
        })
        console.log(clinical);
        wx.request({
          method: 'POST',
          url: `${baseUrl}/crfClinical/save`,
          data: {
            crfClinicalDTOList: clinical
          },
          header: {
            'content-type': 'application/json'
          },
          success({data: {data, statusCode}}) {
            console.log(data)
            if (statusCode == "2000000") {
              
            }
          }
        })
      }
      
      /* let { dateOne, dateTwo, dateThree, dateFour, dateFive, isGroup } = this.data;
      let para = {
        crfId: wx.getStorageSync('crfItem').crfId,
        firstTime: dateThree+' 00:00:00',
        intoDate: dateTwo+' 00:00:00',
        isGroup,
        medicineId: this.data.filObj.medicineInfoName,
        groupName: this.data.filObj.groupName,
        useMedicineTime: dateFour+' 00:00:00',
        nextTime: dateFive+' 00:00:00'
      }
      wx.request({
        method: 'POST',
        url: `${baseUrl}/crfInto/save`,
        data: {
          ...para
        },
        header: {
          'content-type': 'application/json'
        },
        success({data: {data, statusCode}}) {
          console.log(data)
          if (statusCode == "2000000") {
            
          }
        }
      }) */
      
    },
    combine() {
      wx.navigateTo({
        url: '../../pages/mergedrug/mergedrug'
      })
    },
    badevent() {
      wx.navigateTo({
        url: '../../pages/badreport/badreport'
      })
    },
    badyzevent() {
      wx.navigateTo({
        url: '../../pages/badseriousreport/badseriousreport'
      })
    }
  },
  options: {
    multipleSlots: true
  }
})