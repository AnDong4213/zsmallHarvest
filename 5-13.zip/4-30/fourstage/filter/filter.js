Component({
  properties: {
    innerText: {
      type: String,
      value: ''
    }
  },
  data: {
    physique: [
      {
        part: '头颈部',
        sign: 'tou'
      },
      {
        part: '肺脏',
        sign: 'fei'
      },
      {
        part: '心脏',
        sign: 'xin'
      },
      {
        part: '腹部',
        sign: 'fu'
      },
      {
        part: '神经',
        sign: 'shen'
      },
      {
        part: '肌肉/骨骼',
        sign: 'ji'
      },
      {
        part: '皮肤黏膜',
        sign: 'pi'
      },
      {
        part: '淋巴结',
        sign: 'lin'
      },
      {
        part: '四肢',
        sign: 'limb'
      },
      {
        part: '其他',
        sign: 'other'
      }
    ]
  },
  lifetimes: {
    attached () {
      
    }
  },
  methods: {
    radioDrink(e) {
      console.log(e)
    },
    radioSmoke(e) {
      console.log(e)
    },
    customMethod() {
      this.setData({
        someData: '接口2223'
      })
    },
    haha() {
      const myEventDetail = {a: 8888} // detail对象，提供给事件监听函数
      const myEventOption = {bubbles: true} // 触发事件的选项
      this.triggerEvent('myevent', myEventDetail, myEventOption)
    },
    haha3() {
      wx.navigateTo({
        url: '../../pages/login/login'
      })
    }
  },
  options: {
    multipleSlots: true
  }
})