Component({
  properties: {
    innerText: {
      type: String,
      value: '入组期'
    }
  },
  data: {
    symptom: [
      {
        ill: '头疼',
        evaluate: '34'
      },
      {
        ill: '脑热',
        evaluate: '3'
      }
    ],
    num: 0
  },
  methods: {
    midAdd() {
      let symptom = this.data.symptom, num = this.data.num;
      num ++;
      symptom.push(num);
      this.setData({
        symptom,
        num
      })
    },
    midMinus(e) {
      let symptom = this.data.symptom, num = e.currentTarget.dataset.num;
      let index = symptom.findIndex(item => item == num);
      console.log(index)
      symptom.splice(index, 1);
      console.log(symptom)
      this.setData({
        symptom
      })
    }
  },
  options: {
    multipleSlots: true
  }
})