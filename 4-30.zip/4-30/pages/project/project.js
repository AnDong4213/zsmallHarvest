// pages/project/project.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: '1',
    isexpand: true,
    title: '',
    content: "",
    isMask: false,
    isAdd: false,
    isCon: false,
    list: [
      {
        name: '张明星',
        job: '副主任医生',
        hospital: '北京协和医院',
        department: '骨科'
      },
      {
        name: '张明星',
        job: '副主任医生',
        hospital: '北京协和医院',
        department: '骨科'
      }
    ],
    subject: [
      {
        name: '张三',
        gender: '男',
        bir: '1978-09-07'
      },
      {
        name: '王梅',
        gender: '女',
        bir: '1978-09-07'
      },
      {
        name: '张三',
        gender: '男',
        bir: '1978-09-07'
      },
      {
        name: '王梅2',
        gender: '女',
        bir: '1978-09-07'
      },
      {
        name: '张三2',
        gender: '男',
        bir: '1978-09-07'
      },
      {
        name: '王好',
        gender: '女',
        bir: '1978-09-07'
      },
      {
        name: '王好2',
        gender: '女',
        bir: '1978-09-07'
      },
      {
        name: '张三2',
        gender: '男',
        bir: '1978-09-07'
      },
      {
        name: '王好',
        gender: '女',
        bir: '1978-09-07'
      },
      {
        name: '王好2',
        gender: '女',
        bir: '1978-09-07'
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  navbarTap(e) {
    let currentTab = e.currentTarget.dataset.index;
    this.setData({
      currentTab
    })
  },
  isexpand() {
    this.setData({
      isexpand: false
    })
  },
  isCollapse() {
    this.setData({
      isexpand: true
    })
  },
  addTo() {
    this.setData({
      title: '添加受试者',
      isMask: true,
      isAdd: true
    })
  },
  syDesign() {
    this.setData({
      title: '试验设计',
      content: "试验设计试验设计试验设计试验设计",
      isMask: true,
      isCon: true
    })
  },
  syPurpose() {
    this.setData({
      title: '试验目的',
      content: "试验目的介绍试验目的介绍试验目的介绍试验目的介绍试验目的介绍试验目的介绍试验目的介绍",
      isMask: true,
      isCon: true
    })
  },
  zlprograms() {
    this.setData({
      title: '治疗方案',
      content: "治疗方案治疗方案治疗方案治疗方案治疗方案治疗方案",
      isMask: true,
      isCon: true
    })
  },
  zlzhibiao() {
    this.setData({
      title: '治疗指标',
      content: "治疗指标治疗指标治疗指标治疗指标治疗指标治疗指标",
      isMask: true,
      isCon: true
    })
  },
  zlbiaozhun() {
    this.setData({
      title: '疗效判定标准',
      content: "疗效判定标准疗效判定标准疗效判定标准疗效判定标准",
      isMask: true,
      isCon: true
    })
  },
  safezb() {
    this.setData({
      title: '安全性指标',
      content: "安全性指标安全性指标安全性指标安全性指标",
      isMask: true,
      isCon: true
    })
  },
  closeMask() {
    this.setData({
      isMask: false,
      isAdd: false,
      content: '',
      isCon: false
    })
  },
  checkboxChange(e) {
    console.log(e.detail)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})