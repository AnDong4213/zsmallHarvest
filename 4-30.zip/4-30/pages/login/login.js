const util = require('../../utils/util.js'), app = getApp();

Page({
  data: {
    inputPhone: '',
    isDoubleClick: false,
    disabled: true,
    typeJump: '',
    viewHeight: '',
    defaultSize: 'mini',
    resend: true,
    number: 60,
    yzcode: '',
    isExit: false
  },
  valueChange: function(e) {
    if (e.detail.value.length === 11) {
      this.setData({
        disabled: false,
        inputPhone: e.detail.value
      })
    } else {
      this.setData({
        disabled: true,
        inputPhone: e.detail.value
      })
    }
  },
  codeChange(e) {
    this.setData({
      yzcode: e.detail.value
    })
  },
  getCode: function() {
    let that = this, reg = /^1\d{10}$/, inputPhone = this.data.inputPhone.replace(/\s+/g, ''), number = 60;
    if (reg.test(inputPhone)) {
      this.setData({
        resend: false,
        disabled: true,
        number: 60
      })
      let setTime = setInterval(() => {
        if (number < 2) {
          clearInterval(setTime);
          this.setData({
            disabled: false,
            resend: true
          })
        } else {
          number --;
          this.setData({
            number
          })
        }
      }, 1000)
    } else {
      wx.showToast({
        title: '手机号不正确',
        icon: 'success',
        image: '../../images/fail02.png',
        mask: true,
        duration: 1000
      })
    }
    return;
    if (that.data.inputPhone.replace(num, '') != '') {
      wx.showToast({
        title: '手机号码不正确',
        image: '/image/cha.png',
      })
    } else {
      wx.showLoading({
        title: '数据加载中...',
      })
      wx.request({
        url: util.BASE_URL + util.GET_LOGIN_CODE + util.HOST_DETAIL + 'phone=' + that.data.inputPhone,
        
        success: function(res) {
          wx.hideLoading()
          console.log('获取验证码结果', res)
          if (res.data.statusCode == '2000000') {
            wx.navigateTo({
              url: 'code/code?phoneNum=' + that.data.inputPhone + '&type=' + that.data.typeJump,
            })
          } else if (res.data.statusCode == '1111111') {
            that.show("系统繁忙，请稍后再试");
          } else if (res.data.statusCode == '4444444') {
            that.show("网络繁忙，请稍后再试");
          } else if (res.data.statusCode == '3020302' || res.data.statusCode == '3020301') {
            that.show("发送验证码失败");
          }
        },
        fail: function(res) {
          wx.hideLoading()

        }
      })
    }
  },
  login() {
    let that = this, reg = /^1\d{10}$/;
    // this.show("功能开发中，敬请期待");
    let inputPhone = this.data.inputPhone.replace(/\s+/g, ''), yzcode = this.data.yzcode.replace(/\s+/g, '');
    if (!reg.test(inputPhone)) {
      wx.showToast({
        title: '请输入手机号',
        icon: 'none',
        duration: 1000
      })
      return;
    }
    if (yzcode == '') {
      wx.showToast({
        title: '请输入验证码',
        icon: 'none',
        duration: 1000
      })
      return;
    }
    wx.navigateBack({
      delta: 1
    })
    /* wx.navigateTo({
      url: '../index/index'
    }) */
    /* this.setData({
      isExit: true
    }) */
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this;
    /* var type = options.type;
    this.setData({
      typeJump: options.type,
    }); */
    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          viewHeight: (res.windowHeight*0.62*2) + 'rpx'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this
    that.setData({
      isDoubleClick: false,
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  }
})