//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    currentTab: '1',
    list: [
      {
        drugName: '枳术宽中胶囊药物',
        name: '张明星',
        job: '副主任医生',
        hospital: '北京协和医院',
        department: '骨科',
        unit: '朗致制药',
        center: '山西双人药业有限公司'
      },
      {
        drugName: '枳术宽中胶囊药物',
        name: '张明星',
        job: '副主任医生',
        hospital: '北京协和医院',
        department: '骨科',
        unit: '朗致制药',
        center: '山西双人药业有限公司'
      }
    ]
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../login/login'
    })
  },
  onLoad: function () {
    
  },
  onShow() {
    // console.log(this.route)
  },
  navbarTap(e) {
    let currentTab = e.currentTarget.dataset.index;
    this.setData({
      currentTab
    })
  }
})
