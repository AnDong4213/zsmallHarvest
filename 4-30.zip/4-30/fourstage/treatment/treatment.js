Component({
  properties: {
    innerText: {
      type: String,
      value: '治疗期'
    }
  },
  data: {

  },
  methods: {

  },
  options: {
    multipleSlots: true
  }
})