Component({
  properties: {
    innerText: {
      type: String,
      value: '治疗期'
    }
  },
  data: {
    physique: [
      {
        part: '头颈部',
        sign: 'tou'
      },
      {
        part: '肺脏',
        sign: 'fei'
      },
      {
        part: '心脏',
        sign: 'xin'
      },
      {
        part: '腹部',
        sign: 'fu'
      },
      {
        part: '神经',
        sign: 'shen'
      },
      {
        part: '肌肉/骨骼',
        sign: 'ji'
      },
      {
        part: '皮肤黏膜',
        sign: 'pi'
      },
      {
        part: '淋巴结',
        sign: 'lin'
      },
      {
        part: '四肢',
        sign: 'limb'
      },
      {
        part: '其他',
        sign: 'other'
      }
    ]
  },
  methods: {

  },
  options: {
    multipleSlots: true
  }
})