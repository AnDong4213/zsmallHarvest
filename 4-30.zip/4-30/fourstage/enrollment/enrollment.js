Component({
  properties: {
    innerText: {
      type: String,
      value: '入组期'
    }
  },
  data: {
    
  },
  methods: {
   
  },
  options: {
    multipleSlots: true
  }
})