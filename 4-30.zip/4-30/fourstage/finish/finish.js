Component({
  properties: {
    innerText: {
      type: String,
      value: '结束期'
    }
  },
  data: {

  },
  methods: {

  },
  options: {
    multipleSlots: true
  }
})