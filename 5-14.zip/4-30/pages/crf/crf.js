Page({
  data: {
    currentTab: '2',
    item: {
      drugName: '枳术宽中胶囊药物'
    },
    content: "",
    isMask: false,
    isAdd: false,
    isCon: false,
    title: '',
    subject: ['a', 'b', 'c']
  },

  onLoad: function (options) {
    
  },

  navbarTap(e) {
    let currentTab = e.currentTarget.dataset.index;
    this.setData({
      currentTab
    })
  },
  hehe(e) {
    console.log(e)
  },
  closeMask() {
    this.setData({
      isMask: false,
      isAdd: false,
      content: '',
      isCon: false,
      title: ''
    })
  },
  login() {
    this.setData({
      isMask: false,
      isAdd: false,
      content: '',
      isCon: false,
      title: ''
    })
  },
  visitOne() {
    this.setData({
      title: '选择访视',
      isMask: true,
      isAdd: true
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})