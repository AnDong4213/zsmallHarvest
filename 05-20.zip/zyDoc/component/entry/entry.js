Component({
  properties: {
    title: {
      type: String,
      value: ''
    },
    content: {
      type: String,
      value: ''
    },
    isCon: {
      type: Boolean,
      value: false
    }
  },
  data: {

  },
  methods: {
    close() {
      this.triggerEvent('customclose')
    }
  },
  options: {
    multipleSlots: true
  }
})