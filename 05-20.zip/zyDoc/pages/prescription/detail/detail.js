// pages/prescription/detail/detail.js
Page({
  data: {
    code: '',
    list: {
      status: 0,
      dealCode: '4255253',
      createTime: '2019-09-08 12:56',
      patientName: '张三',
      patientSex: 1,
      patientAge: 22,
      patientPhone: '13456784322',
      department: '外科',
      diagnose: '消化不良，预期中介',
      orderGoodsDTO: [
        {
          goodName: '快客胶囊',
          amt: '2',
          units: '盒',
          spec: '12',
          times: '2',
          fews: '2',
          ampms: '饭后',
          price: 32.44
        },
        {
          goodName: '快客胶囊',
          amt: '2',
          units: '盒',
          spec: '12',
          times: '2',
          fews: '2',
          ampms: '饭后',
          price: 53.88
        }
      ],
      consignee: '张三',
      receiptPhone: '13456784322',
      receiptAddress: '北京大兴地泽北街',
      express: '中听快递',
      courierNumber: '346464575855695',
      dealAmount: 3,
      id: '78979687'
    }
  },
  onLoad: function (options) {
    console.log(options)
    /* this.setData({
      code: options.code
    }) */
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})