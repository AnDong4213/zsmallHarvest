// pages/mergedrug/mergedrug.js
Page({
  data: {
    crfUseMedicineDTOList: [
      {
        medicineName: '',
        dosage: '',
        useMethod: '',
        useReason: '',
        startDate: '',
        endDate: '',
        isBad: 0
      }
    ]
  },
  onLoad: function (options) {

  },
  medicineName(e) {
    let crfUseMedicineDTOList = this.data.crfUseMedicineDTOList;
    let idx = e.currentTarget.dataset.idx;
    crfUseMedicineDTOList[idx].medicineName = e.detail.value.replace(/\s/g,"");
    this.setData({
      crfUseMedicineDTOList
    })
  },
  dosage(e) {
    let crfUseMedicineDTOList = this.data.crfUseMedicineDTOList;
    let idx = e.currentTarget.dataset.idx;
    crfUseMedicineDTOList[idx].dosage = e.detail.value.replace(/\s/g,"");
    this.setData({
      crfUseMedicineDTOList
    })
  },
  useMethod(e) {
    let crfUseMedicineDTOList = this.data.crfUseMedicineDTOList;
    let idx = e.currentTarget.dataset.idx;
    crfUseMedicineDTOList[idx].useMethod = e.detail.value.replace(/\s/g,"");
    this.setData({
      crfUseMedicineDTOList
    })
  },
  useReason(e) {
    let crfUseMedicineDTOList = this.data.crfUseMedicineDTOList;
    let idx = e.currentTarget.dataset.idx;
    crfUseMedicineDTOList[idx].useReason = e.detail.value.replace(/\s/g,"");
    this.setData({
      crfUseMedicineDTOList
    })
  },
  startDate(e) {
    let dateH = new Date(), hour = dateH.getHours(), minute = dateH.getMinutes();
    hour = hour < 10 ? '0'+hour : hour;
    minute = minute < 10 ? '0'+minute : minute;
    let sfm = hour + ':' + minute;

    let crfUseMedicineDTOList = this.data.crfUseMedicineDTOList;
    let idx = e.currentTarget.dataset.idx;
    crfUseMedicineDTOList[idx].startDate = e.detail.value + ' ' +sfm+':00';
    this.setData({
      crfUseMedicineDTOList
    })
  },
  endDate(e) {
    let dateH = new Date(), hour = dateH.getHours(), minute = dateH.getMinutes();
    hour = hour < 10 ? '0'+hour : hour;
    minute = minute < 10 ? '0'+minute : minute;
    let sfm = hour + ':' + minute;

    let crfUseMedicineDTOList = this.data.crfUseMedicineDTOList;
    let idx = e.currentTarget.dataset.idx;
    crfUseMedicineDTOList[idx].endDate = e.detail.value + ' ' +sfm+':00';
    this.setData({
      crfUseMedicineDTOList
    })
  },
  isBad(e) {
    let crfUseMedicineDTOList = this.data.crfUseMedicineDTOList;
    let idx = e.currentTarget.dataset.idx;
    crfUseMedicineDTOList[idx].isBad = e.detail.value == 'yes' ? 1 : 0;
    this.setData({
      crfUseMedicineDTOList
    })
  },
  del(e) {
    let crfUseMedicineDTOList = this.data.crfUseMedicineDTOList, length = crfUseMedicineDTOList.length;
    let idx = e.currentTarget.dataset.idx;
    crfUseMedicineDTOList.splice(idx, 1);
    this.setData({
      crfUseMedicineDTOList
    })
  },
  add(e) {
    let crfUseMedicineDTOList = this.data.crfUseMedicineDTOList;
    let idx = crfUseMedicineDTOList.length - 1;
    if (crfUseMedicineDTOList[idx].medicineName != '' && crfUseMedicineDTOList[idx].dosage != '' && crfUseMedicineDTOList[idx].useMethod != '' && crfUseMedicineDTOList[idx].useReason != '' && crfUseMedicineDTOList[idx].startDate != '' && crfUseMedicineDTOList[idx].endDate != '') {
      let obj = {
        medicineName: '',
        dosage: '',
        useMethod: '',
        useReason: '',
        startDate: '',
        endDate: '',
        isBad: 0
      }
      crfUseMedicineDTOList.push(obj);
      this.setData({
        crfUseMedicineDTOList
      })
    } else {
      wx.showToast({
        title: '输入信息不完整',
        icon: 'none',
        duration: 1000
      })
    }
    
  },
  create() {
    let crfUseMedicineDTOList = this.data.crfUseMedicineDTOList;
    let idx = crfUseMedicineDTOList.length - 1;
    if (crfUseMedicineDTOList[idx].medicineName != '' && crfUseMedicineDTOList[idx].dosage != '' && crfUseMedicineDTOList[idx].useMethod != '' && crfUseMedicineDTOList[idx].useReason != '' && crfUseMedicineDTOList[idx].startDate != '' && crfUseMedicineDTOList[idx].endDate != '') {
      wx.setStorageSync('hbyy', crfUseMedicineDTOList);
      wx.navigateBack({
        delta: 1
      })
    } else {
      wx.showToast({
        title: '最后一个用药记录填写不完整',
        icon: 'none',
        duration: 1000
      })
    }
    
  }
})