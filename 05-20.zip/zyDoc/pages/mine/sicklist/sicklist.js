Page({
  data: {
    list: []
  },
  onLoad: function (options) {

  },
  detail() {
    wx.navigateTo({
      url: './../item/item',
    })
  },
  create() {
    wx.redirectTo({
      url: './../new/new',
    })
  }

  
})