// pages/mine/mine.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    item: {
      name: '张明星',
      job: '副主任医生',
      hospital: '北京协和医院',
      department: '骨科',
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  mine() {
    wx.navigateTo({
      url: './sicklist/sicklist',
    })
  },

 
})