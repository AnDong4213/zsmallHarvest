const app = getApp(), baseUrl = app.globalData.baseUrl;

Page({
  data: {
    list: [
      {
        code: '768476934694',
        name: '枳术宽中胶囊',
        num: 7
      },
      {
        code: '7967945769485',
        name: '快克宽中胶囊',
        num: 34
      }
    ]
  },
  onLoad: function () {
    let patientItem = wx.getStorageSync('patientItem'), that = this;
    // console.log(patientItem);
    let { projectId, patientId } = wx.getStorageSync('patientItem');
    wx.request({
      method: 'POST',
      url: `${baseUrl}/projectRecipe/getWholeOnPage`,
      data: {
        projectId,
        patientId
      },
      header: {
        'content-type': 'application/json'
      },
      success({data: {data, statusCode}}) {
        if (statusCode == "2000000") {
          // console.log(data.list)
          that.setData({
            list: data.list
          })
        }
      }
    })
  },
  login() {
    wx.redirectTo({
      url: './addcf/addcf'
    })
  },
  onReady: function () {

  },
  onShow: function () {

  },

 
})