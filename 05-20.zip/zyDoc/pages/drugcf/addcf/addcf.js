const app = getApp(), baseUrl = app.globalData.baseUrl;

Page({
  data: {
    code: '',
    patientItem: {},
    projectRecipeMedicineDTOList: [],
    diagnose: '',
    dealAmount: '',
    useTime: ''
  },
  onLoad: function () {
    // console.log(options);
    //  proItem = wx.getStorageSync('proItem')
    let patientItem = wx.getStorageSync('patientItem'), that = this;
    // console.log(patientItem)
    // console.log(wx.getStorageSync('proItem'))
    let medicineInfo = wx.getStorageSync('medicineInfo'), arrStr = [];
    medicineInfo.forEach(item => {
      arrStr.push(item.medicineId)
    });
    let str = arrStr.join(',');
    let { patientId, projectId, groupId } = patientItem;
    wx.request({
      method: 'GET',
      url: `${baseUrl}/ProjectRecipeMedicineController/getGroupMedicine?medicineIds=${str}`,
      header: {
        'content-type': 'application/json'
      },
      success({data: {data, statusCode}}) {
        if (statusCode == "2000000") {
          let dealAmount = 0;
          data.forEach(item => {
            item.medicineNum = 1;
            if (item.useInfo) {
              item.useInfo = JSON.parse(item.useInfo)
            }
          })
          data.forEach(item => {
            dealAmount += item.medicineNum * item.price;
            if (item.useInfo) {
              item.useInfoItem = item.useInfo.useMethod + ',' + item.useInfo.useFrequency + ',' + item.useInfo.useNumber+item.useInfo.useUnit
            } else {
              item.useInfoItem = ''
            }
          })
          // console.log(data)
          that.setData({
            projectRecipeMedicineDTOList: data,
            dealAmount: Number(dealAmount.toFixed(2))
          })
        }
      }
    });
    this.setData({
      patientItem
    })
  },
  diagnose(e) {
    this.setData({
      diagnose: e.detail.value
    })
  },
  useTime(e) {
    this.setData({
      useTime: e.detail.value
    })
  },
  dosage(e) {
    let data = this.data.projectRecipeMedicineDTOList;
    let idx = e.currentTarget.dataset.idx;
    data[idx].useInfoItem = e.detail.value;
    this.setData({
      projectRecipeMedicineDTOList: data
    })
  },
  nightMinus(e) {
    let idx = e.currentTarget.dataset.idx, projectRecipeMedicineDTOList = this.data.projectRecipeMedicineDTOList;
    let dealAmount = this.data.dealAmount;
    if (projectRecipeMedicineDTOList[idx].medicineNum < 2) {
      projectRecipeMedicineDTOList[idx].medicineNum = 1;
      return
    }
    projectRecipeMedicineDTOList[idx].medicineNum --;
    dealAmount -= Number(projectRecipeMedicineDTOList[idx].price);
    this.setData({
      projectRecipeMedicineDTOList,
      dealAmount: Number(dealAmount.toFixed(2))
    })
  },
  nightAdd(e) {
    let idx = e.currentTarget.dataset.idx, projectRecipeMedicineDTOList = this.data.projectRecipeMedicineDTOList;
    let dealAmount = this.data.dealAmount;
    projectRecipeMedicineDTOList[idx].medicineNum ++;
    dealAmount += Number(projectRecipeMedicineDTOList[idx].price);
    this.setData({
      projectRecipeMedicineDTOList,
      dealAmount: Number(dealAmount.toFixed(2))
    })
  },
  save() {
    let { diagnose, projectRecipeMedicineDTOList, dealAmount, useTime } = this.data, arr = [];
    let projectRecipeDTO = {
      diagnose,
      dealAmount,
      useTime,
      doctorId: this.data.patientItem.doctorId,
      doctorName: wx.getStorageSync('proItem').doctorName,
      patientId: this.data.patientItem.patientId,
      patientName: this.data.patientItem.patientName,
      projectId: this.data.patientItem.projectId
    }
    projectRecipeMedicineDTOList.forEach(item => {
      let obj = {};
      obj.medicinePec = item.spec;
      obj.medicineId = item.medicineId;
      obj.medicineName = item.medicineName;
      obj.medicineNum = item.medicineNum;
      obj.packageUnit = item.packageUnit;
      obj.packing = item.packing;
      obj.useInfo = item.useInfoItem
      arr.push(obj)
    })
    // console.log(projectRecipeDTO)
    // console.log(arr);
    wx.request({
      method: 'POST',
      url: `${baseUrl}/projectRecipe/save`,
      data: {
        projectRecipeDTO,
        projectRecipeMedicineDTOList: arr
      },
      header: {
        'content-type': 'application/json'
      },
      success({data: {data, statusCode}}) {
        if (statusCode == "2000000") {
          wx.showModal({
            confirmText: '继续',
            confirmColor: '#7283E0',
            // content: '处方已成功发送给患者，继续添加处方?',
            content: '处方已成功发送给患者',
            success(res) {
              if (res.confirm) {
                wx.navigateBack({
                  // url: '../../project/project'
                  delta: 1
                })
              } else if (res.cancel) {
                wx.navigateBack({
                  delta: 1
                })
              }
            }
          })
        } else {
          wx.showToast({
            title: '添加失败',
            icon: 'none',
            duration: 1000
          })
        }
      }
    })
  }

})