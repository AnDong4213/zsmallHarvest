// pages/badreport/badreport.js
Page({
  data: {
    badr: []
  },
  onLoad: function (options) {
    // console.log(wx.getStorageSync('crfBadDTOList'));
    this.setData({
      badr: wx.getStorageSync('crfBadDTOList')
    })
  },
  create() {
    wx.redirectTo({
      url: './new/new'
    })
  },
  onReady: function () {

  },
  onShow: function () {

  },
  onHide: function () {

  }
})