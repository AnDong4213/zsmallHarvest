Page({
  data: {
    degreeZ: ['轻', '中', '重'],
    degree: 0,
    degreeindex: 0,
    traitZ: ['阵发性', '持续性', '其他'],
    trait: 1,
    traitindex: 1,
    eventName: '',
    diagnosis: '',
    numberN: '',
    process: '',
    inspect: '',
    inspectIs: false,
    measuresZ: ['剂量不变', '减少剂量', '暂停用药', '停止用药', '试验用药已结束', '其他'],
    measures: 0,
    measuresindex: 0,
    handleProcessIs: false,
    handleProcess: '',
    relationindex: 0,
    relationZ: ['肯定有关', '很可能有关', '可能有关', '可能无关', '肯定无关'],
    relation: 0,
    visitTime: '',
    visit_time: '',
    occurTime: '',
    occur_time: '',
    visitInspectIs: false,
    visitInspect: '',
    transferZ: ['消失/复常', '好装', '未好转', '未知', '有后遗症'],
    transfer: 0,
    transferindex: 0,
    isOut: 0,
    crfBadDTOList: []
  },
  onLoad: function (options) {

  },
  eventName(e) {
    this.setData({
      eventName: e.detail.value
    })
  },
  diagnosis(e) {
    this.setData({
      diagnosis: e.detail.value
    })
  },
  occurTime(e) {
    let dateH = new Date(), hour = dateH.getHours(), minute = dateH.getMinutes();
    hour = hour < 10 ? '0'+hour : hour;
    minute = minute < 10 ? '0'+minute : minute;
    let sfm = hour + ':' + minute;
    this.setData({
      // occurTime: e.detail.value + ' ' + sfm,
      occurTime: e.detail.value + ' ' +sfm+':00'
    })
  },
  degree(e) {
    this.setData({
      degreeindex: e.detail.value,
      // degree: this.data.degreeZ[e.detail.value]
      degree: e.detail.value
    })
  },
  trait(e) {
    this.setData({
      traitindex: e.detail.value,
      // trait: this.data.traitZ[e.detail.value]
      trait: e.detail.value
    })
  },
  numberN(e) {

  },
  process(e) {
    this.setData({
      process: e.detail.value
    })
  },
  inspect(e) {
    if (e.detail.value == 'yes') {
      this.setData({
        inspectIs: true,
        inspect: '1'
      })
    } else {
      this.setData({
        inspectIs: false,
        inspect: '0'
      })
    }
  },
  inspectInput(e) {

  },
  measures(e) {
    this.setData({
      measuresindex: e.detail.value,
      // measures: this.data.measuresZ[e.detail.value]
      measures: e.detail.value
    })
  },
  measuresInput(e) {

  },
  handleProcess(e) {
    if (e.detail.value == 'yes') {
      this.setData({
        handleProcessIs: true,
        handleProcess: '1'
      })
    } else {
      this.setData({
        handleProcessIs: false,
        handleProcess: '0'
      })
    }
  },
  handleProcessInput(e) {

  },
  relation(e) {
    this.setData({
      relationindex: e.detail.value,
      // relation: this.data.relationZ[e.detail.value]
      relation: e.detail.value
    })
  },
  visitTime(e) {
    let dateH = new Date(), hour = dateH.getHours(), minute = dateH.getMinutes();
    hour = hour < 10 ? '0'+hour : hour;
    minute = minute < 10 ? '0'+minute : minute;
    let sfm = hour + ':' + minute;
    this.setData({
      // visitTime: e.detail.value + ' ' + sfm,
      visitTime: e.detail.value + ' ' +sfm+':00'
    })
  },
  visitInspect(e) {
    if (e.detail.value == 'yes') {
      this.setData({
        visitInspectIs: true,
        visitInspect: '1'
      })
    } else {
      this.setData({
        visitInspectIs: false,
        visitInspect: '0'
      })
    }
  },
  visitInspectInput(e) {

  },
  transfer(e) {
    this.setData({
      transferindex: e.detail.value,
      // transfer: this.data.transferZ[e.detail.value]
      transfer: e.detail.value
    })
  },
  transferInput(e) {

  },
  isOut(e) {
    if (e.detail.value == 'yes') {
      this.setData({
        isOut: 1
      })
    } else {
      this.setData({
        isOut: 0
      })
    }
  },

  create() {
    let {
      degree,
      diagnosis,
      eventName,
      handleProcess,
      inspect,
      isOut,
      measures,
      occurTime,
      process,
      relation,
      trait,
      transfer,
      visitInspect,
      visitTime
    } = this.data;
    let para = {
      degree,
      diagnosis,
      eventName,
      handleProcess,
      inspect,
      isOut,
      measures,
      occurTime,
      process,
      relation,
      trait,
      transfer,
      visitInspect,
      visitTime
    };
    if (occurTime == '' || visitTime == '') {
      wx.showToast({
        title: '请选择发生时间和随访时间',
        icon: 'none',
        duration: 2000
      })
    } else {
      let crfBadDTOList = wx.getStorageSync('crfBadDTOList') || [];
      crfBadDTOList.push(para);
      wx.setStorageSync('crfBadDTOList', crfBadDTOList);
      wx.navigateBack({
        delta: 1
      })
    }
    /* wx.navigateTo({
      url: '../badreport'
    }) */
  }

}) 