// pages/badseriousreport/new/new.js
Page({
  data: {
    eventName: '',
    occurTime: '',
    traitZ: ['阵发性', '持续性', '其他'],
    traitindex: '0',
    trait: '0',
    saeSituationZ: ['导致住院', '延长住院时间', '伤残', '功能障碍', '影响工作能力', '导致先天畸形', '危及生命或死亡', '其他'],
    saeSituationindex: '0',
    saeSituation: '0',
    treatmentZ: ['有', '无'],
    treatmentindex: '1',
    treatment: '1',
    measuresZ: ['剂量不变', '减少剂量', '暂停用药', '停止用药', '试验用药已结束', '其他'],
    measuresindex: '0',
    measures: '0',
    relationZ: ['肯定有关', '很可能有关', '可能有关', '可能无关', '肯定无关'],
    relationindex: '0',
    relation: '0',
    transferZ: ['症状消失', '症状持续', '死亡'],
    transferindex: '0',
    transfer: '0',
    endTime: '',
    isOutZ: ['是', '否'],
    isOutindex: '1',
    isOut: '1',
    situationZ: ['未破盲', '已破盲'],
    situationindex: '0',
    situation: '0',
    process: '',
    crfVerybadDTOList: []
  },
  onLoad: function (options) {

  },
  eventName(e) {
    this.setData({
      eventName: e.detail.value
    })
  },
  occurTime(e) {
    let dateH = new Date(), hour = dateH.getHours(), minute = dateH.getMinutes();
    hour = hour < 10 ? '0'+hour : hour;
    minute = minute < 10 ? '0'+minute : minute;
    let sfm = hour + ':' + minute;
    this.setData({
      occurTime: e.detail.value + ' ' +sfm+':00'
    })
  },
  endTime(e) {
    let dateH = new Date(), hour = dateH.getHours(), minute = dateH.getMinutes();
    hour = hour < 10 ? '0'+hour : hour;
    minute = minute < 10 ? '0'+minute : minute;
    let sfm = hour + ':' + minute;
    this.setData({
      endTime: e.detail.value + ' ' +sfm+':00'
    })
  },
  trait(e) {
    this.setData({
      traitindex: e.detail.value,
      trait: e.detail.value
    })
  },
  saeSituation(e) {
    this.setData({
      saeSituationindex: e.detail.value,
      saeSituation: e.detail.value
    })
  },
  treatment(e) {
    this.setData({
      treatmentindex: e.detail.value,
      treatment: e.detail.value
    })
  },
  measures(e) {
    this.setData({
      measuresindex: e.detail.value,
      measures: e.detail.value
    })
  },
  relation(e) {
    this.setData({
      relationindex: e.detail.value,
      relation: e.detail.value
    })
  },
  transfer(e) {
    this.setData({
      transferindex: e.detail.value,
      transfer: e.detail.value
    })
  },
  isOut(e) {
    this.setData({
      isOutindex: e.detail.value,
      isOut: e.detail.value
    })
  },
  situation(e) {
    this.setData({
      situationindex: e.detail.value,
      situation: e.detail.value
    })
  },
  process(e) {
    this.setData({
      process: e.detail.value
    })
  },
  create() {
    let {endTime,
      eventName,
      isOut,
      measures,
      occurTime,
      process,
      relation,
      saeSituation,
      situation,
      trait,
      transfer,
      treatment} = this.data;
    let obj = {
      endTime,
      eventName,
      isOut,
      measures,
      occurTime,
      process,
      relation,
      saeSituation,
      situation,
      trait,
      transfer,
      treatment
    };
    if (occurTime == '' || endTime == '') {
      wx.showToast({
        title: '请选择SAE发生时间和症状消失时间',
        icon: 'none',
        duration: 2000
      })
    } else {
      let crfVerybadDTOList = wx.getStorageSync('crfVerybadDTOList') || [];
      crfVerybadDTOList.push(obj);
      wx.setStorageSync('crfVerybadDTOList', crfVerybadDTOList)
      wx.navigateBack({
        delta: 1
      })
    }
    /* wx.navigateTo({
      url: '../badseriousreport'
    }) */

  }
 
})