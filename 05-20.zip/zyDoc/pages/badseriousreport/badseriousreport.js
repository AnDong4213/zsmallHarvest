// pages/badseriousreport/badseriousreport.js
Page({
  data: {
    badr: []
  },
  onLoad: function () {
    let crfVerybadDTOList = wx.getStorageSync('crfVerybadDTOList');
    this.setData({
      badr: crfVerybadDTOList
    })
  },
  create() {
    wx.redirectTo({
      url: './new/new',
    })
  }
})