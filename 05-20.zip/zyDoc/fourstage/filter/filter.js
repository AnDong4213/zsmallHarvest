const utils = require('./../../utils/util'), app = getApp(), baseUrl = app.globalData.baseUrl;

Component({
  properties: {
    innerText: {
      type: String,
      value: ''
    }
  },
  data: {
    physique: [
      {
        part: '头颈部',
        sign: 'tou'
      },
      {
        part: '肺脏',
        sign: 'fei'
      },
      {
        part: '心脏',
        sign: 'xin'
      },
      {
        part: '腹部',
        sign: 'fu'
      },
      {
        part: '神经',
        sign: 'shen'
      },
      {
        part: '肌肉/骨骼',
        sign: 'ji'
      },
      {
        part: '皮肤黏膜',
        sign: 'pi'
      },
      {
        part: '淋巴结',
        sign: 'lin'
      },
      {
        part: '四肢',
        sign: 'limb'
      },
      {
        part: '其他',
        sign: 'other'
      }
    ],
    date: '',
    echo: {}
  },
  lifetimes: {
    attached () {
      let crfItem = wx.getStorageSync('crfItem'), that = this;
      this.setData({
        date: utils.formatTime(new Date()).split(' ')[0]
      });
      // console.log(crfItem.crfId);
      function second() {
        return new Promise((resolve, reject) => {
          wx.request({
            method: 'GET',
            url: `${baseUrl}/crfChoose/getByCrfId?crfId=${crfItem.crfId}`,
            header: {
              'content-type': 'application/json'
            },
            success({ data: { data, statusCode } }) {
              // console.log(data)
              if (statusCode == "2000000") {
                that.setData({
                  echo: data == null ? {} : data
                });
                if (data != null) {
                  resolve(data.chooseId)
                }
              }
            }
          })
        })
      }
      second().then(res => {
        // console.log(res);
        if (res) {
          wx.request({
            method: 'POST',
            url: `${baseUrl}/crfCheck/getList`,
            data: {
              relationId: res
            },
            header: {
              'content-type': 'application/json'
            },
            success({ data: { data, statusCode } }) {
              // console.log(data)
              if (statusCode == "2000000") {
                // 体格
              }
            }
          })
        }
      })
    }
  },
  methods: {
    radioDrink(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isDrinking: '1'
        })
      } else {
        this.setData({
          isDrinking: '0' 
        })
      }
    },
    radioSmoke(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isSmoking: '1'
        })
      } else {
        this.setData({
          isSmoking: '0'
        })
      }
    },
    radioDrug(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isAllergyMedicine: '1'
        })
      } else {
        this.setData({
          isAllergyMedicine: '0'
        })
      }
    },
    radioOther(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isAllergyOther: '1'
        })
      } else {
        this.setData({
          isAllergyOther: '0'
        })
      }
    },
    radioTreat(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isTreat: '1'
        })
      } else {
        this.setData({
          isTreat: '0'
        })
      }
    },
    radioMerge(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isHistory: '1'
        })
      } else {
        this.setData({
          isHistory: '0'
        })
      }
    },

    radiotou(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkHead: '1'
        })
      } else {
        this.setData({
          checkHead: '0'
        })
      }
    },
    radiofei(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkLungs: '1'
        })
      } else {
        this.setData({
          checkLungs: '0'
        })
      }
    },
    radioxin(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkHeart: '1'
        })
      } else {
        this.setData({
          checkHeart: '0'
        })
      }
    },
    radiofu(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkAbdomen: '1'
        })
      } else {
        this.setData({
          checkAbdomen: '0'
        })
      }
    },
    radioshen(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkNerve: '1'
        })
      } else {
        this.setData({
          checkNerve: '0'
        })
      }
    },
    radioji(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkMuscleSkeleton: '1'
        })
      } else {
        this.setData({
          checkMuscleSkeleton: '0'
        })
      }
    },
    radiopi(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkSkin: '1'
        })
      } else {
        this.setData({
          checkSkin: '0'
        })
      }
    },
    radiolin(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkLymph: '1'
        })
      } else {
        this.setData({
          checkLymph: '0'
        })
      }
    },
    radiolimb(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkLimb: '1'
        })
      } else {
        this.setData({
          checkLimb: '0'
        })
      }
    },
    radioother(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkOther: '1'
        })
      } else {
        this.setData({
          checkOther: '0'
        })
      }
    },

    breathe(e) {
      this.setData({
        signBreathing: e.detail.value
      })
    },
    heartrate(e) {
      this.setData({
        signHeartRate: e.detail.value
      })
    },
    bloodone(e) {
      this.setData({
        bloodone: e.detail.value
      })
    },
    bloodtwo(e) {
      this.setData({
        bloodtwo: e.detail.value
      })
    },
    temperature(e) {
      this.setData({
        signTemperature: e.detail.value
      })
    },
    
    bindDateChange(e) {
      this.setData({
        date: e.detail.value
      })
    },
    haha() {
      const myEventDetail = {a: 8888} // detail对象，提供给事件监听函数
      const myEventOption = {bubbles: true} // 触发事件的选项
      this.triggerEvent('myevent', myEventDetail, myEventOption)
    },
    haha3() {
      wx.navigateTo({
        url: '../../pages/login/login'
      })
    },
    besure() {
      let that = this, crfItem = wx.getStorageSync('crfItem');
      let para = {
        isDrinking: this.data.isDrinking,
        isSmoking: this.data.isSmoking,
        isAllergyMedicine: this.data.isAllergyMedicine,
        isAllergyOther: this.data.isAllergyOther,
        isTreat: this.data.isTreat,
        isHistory: this.data.isHistory,
        chooseDate: this.data.date + ' 00:00:00',
        crfId: crfItem.crfId,
        patientId: crfItem.patientId,
        projectId: crfItem.projectId,
        doctorId: crfItem.doctorId
      };
      let tizhi = {
        checkAbdomen: this.data.checkAbdomen,
        checkHead: this.data.checkHead,
        checkHeart: this.data.checkHeart,
        checkLimb: this.data.checkLimb,
        checkLungs: this.data.checkLungs,
        checkLymph: this.data.checkLymph,
        checkMuscleSkeleton: this.data.checkMuscleSkeleton,
        checkNerve: this.data.checkNerve,
        checkOther: this.data.checkOther,
        checkSkin: this.data.checkSkin,
        signBloodPressure: this.data.bloodone + '/' + this.data.bloodtwo,
        signBreathing: this.data.signBreathing,
        signHeartRate: this.data.signHeartRate,
        signTemperature: this.data.signTemperature
      }
      function first() {
        return new Promise((resolve, reject) => {
          wx.request({
            method: 'POST',
            url: `${baseUrl}/crfChoose/save`,
            data: {
              ...para
            },
            header: {
              'content-type': 'application/json'
            },
            success({data: {data, statusCode}}) {
              if (statusCode == "2000000") {
                resolve(data)
              } else {
                wx.showToast({
                  title: '保存失败',
                  icon: 'none',
                  duration: 1000
                })
              }
            }
          })
        })
      }
      first().then(res => {
        console.log(res.chooseId)
        wx.request({
          method: 'POST',
          url: `${baseUrl}/crfCheck/save`,
          data: {
            ...tizhi,
            relationId: res.chooseId
          },
          header: {
            'content-type': 'application/json'
          },
          success({data: {data, statusCode}}) {
            // console.log(data)
            if (statusCode == "2000000") {
              wx.showToast({
                title: '保存成功',
                icon: 'none',
                duration: 1000
              })
            } else {
              wx.showToast({
                title: '保存失败',
                icon: 'none',
                duration: 1000
              })
            }
          }
        })
      })
      /* if (!this.data.echo.isDrinking) {
        wx.request({
          method: 'POST',
          url: `${baseUrl}/crfChoose/save`,
          data: {
            ...para
          },
          header: {
            'content-type': 'application/json'
          },
          success({data: {data, statusCode}}) {
            console.log(data)
            if (statusCode == "2000000") {
              wx.showToast({
                title: '保存成功',
                icon: 'success',
                duration: 1000
              })
            }
          }
        })
      };
      console.log(tizhi) */

    }
  },
  options: {
    multipleSlots: true
  }
})