const app = getApp(), baseUrl = app.globalData.baseUrl;

Component({
  properties: {
    innerText: {
      type: String,
      value: '治疗期'
    }
  },
  data: {
    physique: [
      {
        part: '头颈部',
        sign: 'tou'
      },
      {
        part: '肺脏',
        sign: 'fei'
      },
      {
        part: '心脏',
        sign: 'xin'
      },
      {
        part: '腹部',
        sign: 'fu'
      },
      {
        part: '神经',
        sign: 'shen'
      },
      {
        part: '肌肉/骨骼',
        sign: 'ji'
      },
      {
        part: '皮肤黏膜',
        sign: 'pi'
      },
      {
        part: '淋巴结',
        sign: 'lin'
      },
      {
        part: '四肢',
        sign: 'limb'
      },
      {
        part: '其他',
        sign: 'other'
      }
    ],
    shifou: false,
    isOntime: '',
    visitDate: '',

    realDays: '',
    days: '',
    realDose: '',
    dose: '',
    subInfo: '',
    nextDate: '',
    isEnd: '',

    clinical: [],
    initialzz: '',
    initialpg: '',

    checkAbdomen: "",
    checkHead: "",
    checkHeart: "",
    checkLimb: "",
    checkLungs: "",
    checkLymph: "",
    checkMuscleSkeleton: "",
    checkNerve: "",
    checkOther: "",
    checkSkin: "",
    signBloodPressure: "",
    signBreathing: "",
    signHeartRate: "",
    signTemperature: ""

  },
  methods: {
    visitOne() {
      this.triggerEvent('customvisit')
    },
    shifou(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          shifou: true,
          isOntime: '1'
        })
      } else {
        this.setData({
          shifou: false,
          isOntime: '0'
        })
      }
    },
    bindDateChangeOne(e) {
      this.setData({
        visitDate: e.detail.value
      })
    },

    bindDateChangeTwo(e) {
      this.setData({
        nextDate: e.detail.value
      })
    },
    isEnd(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isEnd: '1'
        })
      } else {
        this.setData({
          isEnd: '0'
        })
      }
    },
    realDays(e) {
      this.setData({
        realDays: e.detail.value
      })
    },
    days(e) {
      this.setData({
        days: e.detail.value
      })
    },
    realDose(e) {
      let dose = parseInt(this.data.dose);
      let per = ((parseInt(e.detail.value) / dose) * 100).toFixed(2);
      this.setData({
        realDose: e.detail.value,
        subInfo: isNaN(per) ? '' : per
      })
    },
    dose(e) {
      let realDose = parseInt(this.data.realDose);
      let per = ((realDose / parseInt(e.detail.value)) * 100).toFixed(2);
      this.setData({
        dose: e.detail.value,
        subInfo: isNaN(per) ? '' : per
      })
    },

    combine() {
      wx.navigateTo({
        url: '../../pages/mergedrug/mergedrug'
      })
    },
    badevent() {
      wx.navigateTo({
        url: '../../pages/badreport/badreport'
      })
    },
    badyzevent() {
      wx.navigateTo({
        url: '../../pages/badseriousreport/badseriousreport'
      })
    },
    givedrug() {
      wx.navigateTo({
        url: '../../pages/drugcf/drugcf'
      })
    },
    initialzz(e) {
      this.setData({
        initialzz: e.detail.value
      })
    },
    initialpg(e) {
      this.setData({
        initialpg: e.detail.value
      })
    },
    initialzzAll(e) {
      let idx = e.currentTarget.dataset.idx, clinical = this.data.clinical;
      clinical[idx].symptom = e.detail.value;
      this.setData({
        clinical
      })
    },
    initialpgAll(e) {
      let idx = e.currentTarget.dataset.idx, clinical = this.data.clinical;
      clinical[idx].score = e.detail.value;
      this.setData({
        clinical
      })
    },
    midAdd() {
      let clinical = this.data.clinical, obj = {};
      let initialzz = this.data.initialzz, initialpg = this.data.initialpg;
      if (initialzz != '' && initialpg != '') {
        if (clinical.length > 0) {
          let idx = clinical.length - 1;
          if (clinical[idx].symptom != '' && clinical[idx].score != '') {
            obj.symptom = '';
            obj.score = '';
            clinical.push(obj);
            this.setData({
              clinical
            });
            return
          } else {
            wx.showToast({
              title: '请输入症状和评估值',
              icon: 'none',
              duration: 1000
            })
          }
          return
        }
        obj.symptom = '';
        obj.score = '';
        clinical.push(obj);
        this.setData({
          clinical
        })
      } else {
        wx.showToast({
          title: '请输入症状和评估值',
          icon: 'none',
          duration: 1000
        })
      }
    },
    midMinus(e) {
      let clinical = this.data.clinical, idx = e.currentTarget.dataset.idx;
      clinical.splice(idx, 1);
      this.setData({
        clinical
      })
    },

    radiotou(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkHead: '1'
        })
      } else {
        this.setData({
          checkHead: '0'
        })
      }
    },
    radiofei(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkLungs: '1'
        })
      } else {
        this.setData({
          checkLungs: '0'
        })
      }
    },
    radioxin(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkHeart: '1'
        })
      } else {
        this.setData({
          checkHeart: '0'
        })
      }
    },
    radiofu(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkAbdomen: '1'
        })
      } else {
        this.setData({
          checkAbdomen: '0'
        })
      }
    },
    radioshen(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkNerve: '1'
        })
      } else {
        this.setData({
          checkNerve: '0'
        })
      }
    },
    radioji(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkMuscleSkeleton: '1'
        })
      } else {
        this.setData({
          checkMuscleSkeleton: '0'
        })
      }
    },
    radiopi(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkSkin: '1'
        })
      } else {
        this.setData({
          checkSkin: '0'
        })
      }
    },
    radiolin(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkLymph: '1'
        })
      } else {
        this.setData({
          checkLymph: '0'
        })
      }
    },
    radiolimb(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkLimb: '1'
        })
      } else {
        this.setData({
          checkLimb: '0'
        })
      }
    },
    radioother(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          checkOther: '1'
        })
      } else {
        this.setData({
          checkOther: '0'
        })
      }
    },
    breathe(e) {
      this.setData({
        signBreathing: e.detail.value
      })
    },
    heartrate(e) {
      this.setData({
        signHeartRate: e.detail.value
      })
    },
    bloodone(e) {
      this.setData({
        bloodone: e.detail.value
      })
    },
    bloodtwo(e) {
      this.setData({
        bloodtwo: e.detail.value
      })
    },
    temperature(e) {
      this.setData({
        signTemperature: e.detail.value
      })
    },

    besure() {
      let dateH = new Date(), hour = dateH.getHours(), minute = dateH.getMinutes();
      let year = dateH.getFullYear(), month = dateH.getMonth() + 1, day = dateH.getDate();
      month = month < 10 ? '0'+month : month;
      day = day < 10 ? '0'+day : day;
      hour = hour < 10 ? '0'+hour : hour;
      minute = minute < 10 ? '0'+minute : minute;
      let nyr = year+'-'+month+'-'+day, sfm = hour + ':' + minute+':00';

      let { isOntime, visitDate, realDays, days, realDose, dose, subInfo, nextDate, isEnd } = this.data;
      let { checkAbdomen, checkHead, checkHeart, checkLimb, checkLungs, checkLymph, checkMuscleSkeleton, checkNerve, checkOther,checkSkin, signBreathing, signHeartRate, signTemperature } = this.data;
      if (nextDate == '') {
        nextDate = nyr
      }
      if (visitDate == '') {
        visitDate = nyr
      }
      // console.log(wx.getStorageSync('crfItem'))
      let crfTreatDTO = {
        visitDate: visitDate + ' ' +sfm,
        isOntime: parseInt(isOntime),
        crfId: wx.getStorageSync('crfItem').crfId,
        visitName: '访视1'
      }
      let crfSubDTO = {
        realDays: parseInt(realDays),
        days: parseInt(days),
        realDose: parseInt(realDose),
        dose: parseInt(dose),
        subInfo,
        nextDate: nextDate + ' ' + sfm,
        isEnd: parseInt(isEnd)
      }
      let crfCheckDTO = {
        checkAbdomen,
        checkHead,
        checkHeart,
        checkLimb,
        checkLungs,
        checkLymph,
        checkMuscleSkeleton,
        checkNerve,
        checkOther,
        checkSkin,
        signBreathing,
        signHeartRate,
        signTemperature,
        signBloodPressure: this.data.bloodone + '/' + this.data.bloodtwo
      }
      //if (this.data.initialzz != '') {
        let clinical = this.data.clinical;
        clinical.unshift({symptom: this.data.initialzz, score: this.data.initialpg});
        clinical.forEach(item => {
          item.score = parseInt(item.score)
        })
        // console.log(clinical)
      //};

      /* console.log(crfTreatDTO)
      console.log(crfSubDTO)
      console.log(crfCheckDTO)
      console.log(clinical)
      console.log(wx.getStorageSync('crfBadDTOList'))
      console.log(wx.getStorageSync('crfVerybadDTOList'))
      console.log(wx.getStorageSync('hbyy'))
 */

      wx.request({
        method: 'POST',
        url: `${baseUrl}/crfTreat/save`,
        data: {
          crfTreatDTO,
          crfSubDTO,
          crfCheckDTO,
          crfBadDTOList: wx.getStorageSync('crfBadDTOList') == '' ? [] : wx.getStorageSync('crfBadDTOList'),
          crfVerybadDTOList: wx.getStorageSync('crfVerybadDTOList') == '' ? [] : wx.getStorageSync('crfVerybadDTOList'),
          crfUseMedicineDTOList: wx.getStorageSync('hbyy') == '' ? [] : wx.getStorageSync('hbyy'),
          crfClinicalDTOList: clinical

        },
        header: {
          'content-type': 'application/json'
        },
        success({data: {data, statusCode}}) {
          if (statusCode == "2000000") {
            wx.removeStorageSync('crfBadDTOList');
            wx.removeStorageSync('crfVerybadDTOList');
            wx.removeStorageSync('hbyy');
            wx.showToast({
              title: '保存成功',
              icon: 'none',
              duration: 1000
            })
          } else {
            wx.showToast({
              title: '保存失败',
              icon: 'none',
              duration: 1000
            })
          }
        }
      })
      
      
    }

  },
  options: {
    multipleSlots: true
  }
})