Component({
  properties: {
    innerText: {
      type: String,
      value: '结束期'
    }
  },
  data: {
    startDate: '',
    endDate: '',
    visitDate: '',
    isHaveBad: '',
    isSolve: '',
    isFinish: '',
    outDate: '',
    outReason: '',
    isQualified: ''
  },
  methods: {
    startDate(e) {
      this.setData({
        startDate: e.detail.value
      })
    },
    endDate(e) {
      this.setData({
        endDate: e.detail.value
      })
    },
    visitDate(e) {
      this.setData({
        visitDate: e.detail.value
      })
    },
    isHaveBad(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isHaveBad: 1
        })
      } else {
        this.setData({
          isHaveBad: 0
        })
      }
    },
    isSolve(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isSolve: 1
        })
      } else {
        this.setData({
          isSolve: 0
        })
      }
    },
    isFinish(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isFinish: 1
        })
      } else {
        this.setData({
          isFinish: 0
        })
      }
    },
    outDate(e) {
      this.setData({
        outDate: e.detail.value
      })
    },
    outReason(e) {
      this.setData({
        outReason: e.detail.value
      })
    },
    isQualified(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          isQualified: 1
        })
      } else {
        this.setData({
          isQualified: 0
        })
      }
    }
  },
  options: {
    multipleSlots: true
  }
})