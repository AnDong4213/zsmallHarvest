const app = getApp(), baseUrl = app.globalData.baseUrl;

Component({
  properties: {
    innerText: {
      type: String,
      value: '入组期'
    },
    filObj: {
      type: Object,
      value: {}
    }
  },
  data: {
    clinical: [],
    num: 0,
    dateOne: '',
    dateTwo: '',
    dateThree: '',
    dateFour: '',
    dateFive: '',
    initialzz: '',
    initialpg: '',
    ifjoin: true,
    standardr: [],
    standardp: [],
    isGroup: '1',
    enterData: {},
    crfList: []
  },
  lifetimes: {
    attached () {
      let crfItem = wx.getStorageSync('crfItem'), that = this;
      // console.log(crfItem);
      wx.request({
        method: 'POST',
        url: `${baseUrl}/projectChoose/getList`,
        data: {
          projectId: wx.getStorageSync('crfItem').projectId
        },
        header: {
          'content-type': 'application/json'
        },
        success({data: {data, statusCode}}) {
          if (statusCode == "2000000") {
            let standardr = data.filter(item => item.chooseType == 1);
            let standardp = data.filter(item => item.chooseType == 2);
            that.setData({
              standardr,
              standardp
            })
          }
        }
      })


    }
  },
  methods: {
    bindDateChangeOne(e) {
      this.setData({
        dateOne: e.detail.value
      })
    },
    bindDateChangeTwo(e) {
      this.setData({
        dateTwo: e.detail.value
      })
    },
    bindDateChangeThree(e) {
      this.setData({
        dateThree: e.detail.value
      })
    },
    bindDateChangeFour(e) {
      this.setData({
        dateFour: e.detail.value
      })
    },
    bindDateChangeFive(e) {
      this.setData({
        dateFive: e.detail.value
      })
    },
    initialzz(e) {
      this.setData({
        initialzz: e.detail.value
      })
    },
    initialpg(e) {
      this.setData({
        initialpg: e.detail.value
      })
    },
    initialzzAll(e) {
      let idx = e.currentTarget.dataset.idx, clinical = this.data.clinical;
      clinical[idx].symptom = e.detail.value;
      this.setData({
        clinical
      })
    },
    initialpgAll(e) {
      let idx = e.currentTarget.dataset.idx, clinical = this.data.clinical;
      clinical[idx].score = e.detail.value;
      this.setData({
        clinical
      })
    },
    midAdd() {
      let clinical = this.data.clinical, obj = {};
      let initialzz = this.data.initialzz, initialpg = this.data.initialpg;
      if (initialzz != '' && initialpg != '') {
        if (clinical.length > 0) {
          let idx = clinical.length - 1;
          if (clinical[idx].symptom != '' && clinical[idx].score != '') {
            obj.symptom = '';
            obj.score = '';
            clinical.push(obj);
            this.setData({
              clinical
            });
            return
          } else {
            wx.showToast({
              title: '请输入症状和评估值',
              icon: 'none',
              duration: 1000
            })
          }
          return
        }
        obj.symptom = '';
        obj.score = '';
        clinical.push(obj);
        this.setData({
          clinical
        })
      } else {
        wx.showToast({
          title: '请输入症状和评估值',
          icon: 'none',
          duration: 1000
        })
      }
    },
    midMinus(e) {
      let clinical = this.data.clinical, idx = e.currentTarget.dataset.idx;
      clinical.splice(idx, 1);
      this.setData({
        clinical
      })
    },
    ifjoin(e) {
      if (e.detail.value == 'yes') {
        this.setData({
          ifjoin: true,
          isGroup: '1'
        })
      } else {
        this.setData({
          ifjoin: false,
          isGroup: '0'
        })
      }
    },
    selected(e) {
      console.log(e.detail.value)
    },
    grouping() {
      if (!this.data.enterData.intoId) {
        this.triggerEvent('grouping');
      }
    },
    login() {
      let dateH = new Date(), hour = dateH.getHours(), minute = dateH.getMinutes();
      let year = dateH.getFullYear(), month = dateH.getMonth() + 1, day = dateH.getDate();
      month = month < 10 ? '0'+month : month;
      day = day < 10 ? '0'+day : day;
      hour = hour < 10 ? '0'+hour : hour;
      minute = minute < 10 ? '0'+minute : minute;
      let nyr = year+'-'+month+'-'+day, sfm = hour + ':' + minute+':00';

      let clinical = this.data.clinical;
      if (this.data.initialzz != '') {
        clinical.unshift({symptom: this.data.initialzz, score: this.data.initialpg});
      };
      let crfClinicalDTOList = clinical;
      
      let { dateOne, dateTwo, dateThree, dateFour, dateFive, isGroup } = this.data;
      if (dateTwo == '') {
        dateTwo = nyr
      }
      if (dateThree == '') {
        dateThree = nyr
      }
      if (dateFour == '') {
        dateFour = nyr
      }
      if (dateFive == '') {
        dateFive = nyr
      }
      let crfIntoDTO = {
        crfId: wx.getStorageSync('crfItem').crfId,
        firstTime: dateThree+' '+sfm,
        intoDate: dateTwo+' '+sfm,
        isGroup,
        medicineId: this.data.filObj.medicineInfoName,
        groupName: this.data.filObj.groupName,
        useMedicineTime: dateFour+' '+sfm,
        nextTime: dateFive+' '+sfm
      };
      
      let crfBadDTOList = wx.getStorageSync('crfBadDTOList') || [];
      let crfVerybadDTOList = wx.getStorageSync('crfVerybadDTOList') || [];
      let crfUseMedicineDTOList = wx.getStorageSync('hbyy') || [];

      /* console.log(crfClinicalDTOList)
      console.log(crfIntoDTO)
      console.log(crfBadDTOList)
      console.log(crfVerybadDTOList)
      console.log(crfUseMedicineDTOList) */

      wx.request({
        method: 'POST',
        url: `${baseUrl}/crfInto/save`,
        data: {
          crfClinicalDTOList,
          crfIntoDTO,
          crfBadDTOList,
          crfVerybadDTOList,
          crfUseMedicineDTOList
        },
        header: {
          'content-type': 'application/json'
        },
        success({data: {data, statusCode}}) {
          // console.log(data)
          if (statusCode == "2000000") {
            wx.showToast({
              title: '保存成功',
              icon: 'none',
              duration: 1000
            })
            wx.removeStorageSync('crfBadDTOList');
            wx.removeStorageSync('crfVerybadDTOList');
            wx.removeStorageSync('hbyy');
          } else {
            wx.showToast({
              title: '保存失败',
              icon: 'none',
              duration: 1000
            })
          }
        }
      })
      
    },
    combine() {
      wx.navigateTo({
        url: '../../pages/mergedrug/mergedrug'
      })
    },
    badevent() {
      wx.navigateTo({
        url: '../../pages/badreport/badreport'
      })
    },
    badyzevent() {
      wx.navigateTo({
        url: '../../pages/badseriousreport/badseriousreport'
      })
    }
  },
  options: {
    multipleSlots: true
  }
})