const app = getApp(), baseUrl = app.globalData.baseUrl;

Page({
  data: {
    currentTab: '0',
    item: {
      drugName: '枳术宽中胶囊药物'
    },
    content: "",
    isMask: false,
    isAdd: false,
    isCon: false,
    title: '',
    subject: ['a', 'b', 'c'],
    patientItem: {},
    proItem: {}
  },

  onLoad: function () {
    let patientItem = wx.getStorageSync('patientItem'), proItem = wx.getStorageSync('proItem'), crfItem = wx.getStorageSync('crfItem');
    console.log(patientItem)
    console.log(proItem)
    this.setData({
      patientItem,
      proItem
    });
    if (!crfItem.crfId) {
      wx.request({
        method: 'POST',
        url: `${baseUrl}/crf/save`,
        data: {
          projectId: proItem.projectId,
          doctorId: proItem.doctorId,
          patientId: patientItem.patientId
        },
        header: {
          'content-type': 'application/json'
        },
        success({data: {data, statusCode}}) {
          if (statusCode == "2000000") {
            wx.setStorageSync('crfItem', data)
          }
        }
      })
    }
  },
  navbarTap(e) {
    let currentTab = e.currentTarget.dataset.index;
    this.setData({
      currentTab
    })
  },
  hehe(e) {
    console.log(e)
  },
  closeMask() {
    this.setData({
      isMask: false,
      isAdd: false,
      content: '',
      isCon: false,
      title: ''
    })
  },
  login() {
    this.setData({
      isMask: false,
      isAdd: false,
      content: '',
      isCon: false,
      title: ''
    })
  },
  visitOne() {
    this.setData({
      title: '选择访视',
      isMask: true,
      isAdd: true
    })
  }
})