//index.js
//获取应用实例
const app = getApp(), baseUrl = app.globalData.baseUrl;

Page({
  data: {
    currentTab: '1',
    list: [
      {
        drugName: '枳术宽中胶囊药物',
        name: '张明星',
        job: '副主任医生',
        hospital: '北京协和医院',
        department: '骨科',
        unit: '朗致制药',
        center: '山西双人药业有限公司'
      },
      {
        drugName: '枳术宽中胶囊药物',
        name: '张明星',
        job: '副主任医生',
        hospital: '北京协和医院',
        department: '骨科',
        unit: '朗致制药',
        center: '山西双人药业有限公司'
      }
    ]
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../login/login'
    })
  },
  about(e) {
    let doctorItem = wx.getStorageSync('doctorItem'), that = this, projectType;
    console.log(doctorItem)
    if (e == undefined) {
      projectType = this.data.currentTab
    } else {
      projectType = e
    }
    wx.request({
      method: 'GET',
      url: `${baseUrl}/project/getMyCreate?doctorId=${doctorItem.doctorId}&projectType=${projectType}`,
      header: {
        'content-type': 'application/json'
      },
      success({data: {data, statusCode}}) {
        if (statusCode == "2000000") {
          // console.log(data)
          that.setData({
            list: data
          })
        }
      }
    })
  },
  onLoad: function () {
    // console.log(wx.getStorageSync('doctorItem'));
    this.about();
  },
  onShow() {
    // console.log(this.route)
  },
  navbarTap(e) {
    let currentTab = e.currentTarget.dataset.index;
    this.about(currentTab);
    this.setData({
      currentTab
    })
  },
  detail(e) {
    wx.setStorageSync('proItem', e.currentTarget.dataset.item);
    wx.navigateTo({
      url: './../project/project'
    })
  }
})
